package com.hostel.hostelserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HostelserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
