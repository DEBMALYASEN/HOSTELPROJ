package com.hostel.hostelserver.repo;

import com.hostel.hostelserver.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface roleRepo extends JpaRepository<roleRepo,Long>
{

}





