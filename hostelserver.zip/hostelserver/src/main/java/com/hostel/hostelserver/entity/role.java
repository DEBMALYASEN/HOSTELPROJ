package com.hostel.hostelserver.entity;
import javax.persistence.*;
@Entity
@Access(AccessType.PROPERTY)
@Table(name="role")
public class role
{
    @Id
    private Long rollId;
    private String rollName;

    public role(Long rollId, String rollName)
    {
        this.rollId = rollId;
        this.rollName = rollName;
    }

    public role()
    {

    }

    public Long getRollId() {
        return rollId;
    }

    public void setRollId(Long rollId) {
        this.rollId = rollId;
    }

    public String getRollName() {
        return rollName;
    }

    public void setRollName(String rollName) {
        this.rollName = rollName;
    }
}
