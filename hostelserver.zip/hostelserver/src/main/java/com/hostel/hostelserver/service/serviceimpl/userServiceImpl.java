package com.hostel.hostelserver.service.serviceimpl;

import com.hostel.hostelserver.entity.User;

import com.hostel.hostelserver.entity.userRole;
import com.hostel.hostelserver.repo.roleRepo;
import com.hostel.hostelserver.repo.userRepo;
import com.hostel.hostelserver.service.userService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;
@Service
public class userServiceImpl implements userService
{
    @Autowired
    private userRepo uRepo;
    @Autowired
    private roleRepo rRepo;

    @Override
    public User createUser(User user, Set<userRole> userRoles) throws Exception
    {

          User local=this.uRepo.findByUsername(user.getUsername());
          if(local!=null)
        {
            System.out.println("User already present");
            throw new Exception("User already present");
        }
         else
        {
            //user create

            for(userRole ur: userRoles)
                rRepo.save(ur.getRole());

            user.getUserRole().addAll(userRoles);
            this.uRepo.save(user);

        }
        return local;
    }

}
