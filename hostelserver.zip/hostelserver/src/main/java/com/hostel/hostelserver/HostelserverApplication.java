package com.hostel.hostelserver;

import com.hostel.hostelserver.entity.User;
import com.hostel.hostelserver.entity.role;
import com.hostel.hostelserver.entity.userRole;
import com.hostel.hostelserver.service.serviceimpl.userServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.HashSet;
import java.util.Set;

@SpringBootApplication
public class HostelserverApplication implements CommandLineRunner
{

	private userServiceImpl userService;

	public static void main(String[] args)
	{
		SpringApplication.run(HostelserverApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Starting");


		User user = new User();
		user.setFirstName("Debmalya ");
		user.setLastName("Sen");
		user.setEmail("boonysen@gmail.com");


		role r1 = new role();
		r1.setRollId(100L);
		r1.setRollName("Admin");


		Set<userRole> userRoleSet = new HashSet<>();

		userRole userrole = new userRole();
		userrole.setRole(r1);
		;
		userrole.setUser(user);
		userRoleSet.add(userrole);


		User user1 = this.userService.createUser(user, userRoleSet);


		System.out.println(user1.getUsername());
	}
}
