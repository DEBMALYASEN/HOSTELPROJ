package com.hostel.hostelserver.service;

import com.hostel.hostelserver.entity.User;
import com.hostel.hostelserver.entity.userRole;

import java.util.Set;

public interface userService
{
    public User createUser(User user, Set<userRole> userRoles) throws Exception;

}
